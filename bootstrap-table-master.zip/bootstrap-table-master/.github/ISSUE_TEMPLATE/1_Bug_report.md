---
name: 🐛 Bug Report
about: Report errors and problems
labels: Bug

---

**Bootstraptable version(s) affected**:
<!-- The version you currently use/tested -->

**Description**  
<!-- What kind of error/problem you are affected by -->

**Example**  
<!-- Please use our online Editor (https://live.bootstrap-table.com/) to create a example.
     On our Wiki (https://github.com/wenzhixin/bootstrap-table/wiki/Online-Editor-Explanation) you can read how to use the editor.-->

**Possible  (optional)**  
<!--- If you have suggestions on a fix/reason for the bug, please describe it here -->

**Additional context**  
<!-- Optional: any other context about the problem: browser version, operation system,  etc. -->


<!-- Love bootstrap-table? Please consider supporting our collective:
👉  https://opencollective.com/bootstrap-table/donate -->